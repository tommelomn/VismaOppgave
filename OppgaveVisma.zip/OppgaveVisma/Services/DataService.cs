using System.Data;
using OppgaveVisma.Data;
using OppgaveVisma.Models;

namespace OppgaveVisma.Services
{
    // Enkel dataservice: CRUD + regel for oppgave innenfor stillingsperiode
    public class DataService
    {
        private readonly AppDbContext _db;

        public DataService(AppDbContext db)
        {
            _db = db;
            _db.Database.EnsureCreated();
        }

        public List<Ansatt> HentAlleAnsatte() => _db.Ansatte.OrderBy(a => a.Navn).ToList();
        public List<Stilling> HentAlleStillinger() => _db.Stillinger.OrderBy(s => s.Start).ToList();
        public List<Oppgave> HentAlleOppgaver() => _db.Oppgaver.OrderBy(o => o.Dato).ToList();

        public Ansatt? FinnAnsatt(string id) => _db.Ansatte.Find(id);
        public Stilling? FinnStilling(int id) => _db.Stillinger.Find(id);
        public Oppgave? FinnOppgave(int id) => _db.Oppgaver.Find(id);

        public Ansatt LeggTilAnsatt(string id, string navn)
        {
            ValiderAnsattId(id);
            ValiderNavn(navn);

            // Finnes allerede?
            var eksisterende = _db.Ansatte.Find(id);
            if (eksisterende != null) throw new DuplicateNameException("Bruker med dette fødselsnummeret finnes allerede.");

            var a = new Ansatt { Id = id, Navn = navn.Trim() };
            _db.Ansatte.Add(a);
            _db.SaveChanges();
            return a;
        }

        public Stilling LeggTilStilling(string ansattId, string navn, DateOnly start, DateOnly slutt)
        {
            var ansatt = FinnAnsatt(ansattId);
            if (ansatt is null) throw new Exception($"Ansatt ikke funnet. {ansattId}");

            ValiderNavn(navn);
            if (slutt < start) throw new ArgumentException("Sluttdato kan ikke være før startdato.", nameof(slutt));

            // Samme periode/tittel skal være unik pr ansatt
            var eksisterende = _db.Stillinger.Where(s => s.AnsattId == ansatt.Id).ToList();
            if (eksisterende.Any(s => s.Navn == navn.Trim() && s.Start == start && s.Slutt == slutt))
            {
                throw new DuplicateNameException("Stillingen finnes allerede for denne ansatte.");
            }

            // Sjekk for overlappende perioder
            if (eksisterende.Any(s => !(slutt < s.Start || start > s.Slutt)))
            {
                throw new InvalidDataException("Stillingsperioden overlapper med en eksisterende stilling for denne ansatte.");
            }

            var stilling = new Stilling { AnsattId = ansatt.Id, Navn = navn.Trim(), Start = start, Slutt = slutt };
            _db.Stillinger.Add(stilling);
            _db.SaveChanges();
            return stilling;
        }

        public Oppgave? LeggTilOppgave(string ansattId, string navn, DateOnly dato)
        {
            var ansatt = FinnAnsatt(ansattId);
            if (ansatt is null)
            {
                throw new Exception($"Ansatt ikke funnet. {ansattId}");
            }

            ValiderNavn(navn);

            // Sjekk om oppgaven allerede finnes (unikhet: AnsattId, Navn, Dato)
            bool finnes = _db.Oppgaver.Any(o => o.AnsattId == ansatt.Id && o.Navn == navn.Trim() && o.Dato == dato);
            if (finnes)
                throw new DuplicateNameException("Oppgaven ignorert: finnes allerede.");

            // Forretningsregel: Oppgaven må ligge innenfor minst én stillingsperiode
            if (!ErOppgaveInnenforGyldigStilling(ansatt.Id, dato))
                throw new InvalidDataException("Oppgaven ble ignorert (datoen faller ikke innenfor noen stillingsperiode for den ansatte).");

            var oppgave = new Oppgave { AnsattId = ansatt.Id, Navn = navn.Trim(), Dato = dato };
            _db.Oppgaver.Add(oppgave);
            _db.SaveChanges();
            return oppgave;
        }

        public bool ErOppgaveInnenforGyldigStilling(string ansattId, DateOnly dato)
            => _db.Stillinger.Where(s => s.AnsattId == ansattId).Any(s => s.Start <= dato && dato <= s.Slutt);

        public void ValiderAnsattId(string ansattId)
        {
            if (ansattId.Length != 11) throw new ArgumentException("Ugyldig AnsattID: Fødselsnummer må være 11 siffer.", nameof(ansattId));
        }

        public void ValiderNavn(string navn)
        {
            if (string.IsNullOrWhiteSpace(navn)) throw new ArgumentException("Navn kan ikke være tomt.", nameof(navn));
        }

        public bool SlettAnsatt(string id)
        {
            var a = _db.Ansatte.Find(id);
            if (a == null) return false;
            _db.Ansatte.Remove(a);
            _db.SaveChanges();
            return true;
        }

        public bool SlettStilling(int id)
        {
            var s = _db.Stillinger.Find(id);
            if (s == null) return false;
            _db.Stillinger.Remove(s);
            _db.SaveChanges();
            return true;
        }

        public bool SlettOppgave(int id)
        {
            var o = _db.Oppgaver.Find(id);
            if (o == null) return false;
            _db.Oppgaver.Remove(o);
            _db.SaveChanges();
            return true;
        }
    }
}

﻿﻿using System.Data;
using System.Globalization;
using OppgaveVisma.Data;
using OppgaveVisma.Services;

namespace OppgaveVisma
{
    // Konsollapp: meny + input + kall til DataService
    internal class Program
    {
        private const string DatoFormat = "yyyy-MM-dd";
        private static DataService _svc = null!;

        private static void Main(string[] args)
        {
            using var db = new AppDbContext();
            _svc = new DataService(db);

            while (true)
            {
                Console.WriteLine();
                Console.WriteLine("=== MENY ===");
                Console.WriteLine("1.  List ansatte");
                Console.WriteLine("2.  List stillinger");
                Console.WriteLine("3.  List oppgaver");
                Console.WriteLine("4.  Finn ansatt");
                Console.WriteLine("5.  Finn stilling");
                Console.WriteLine("6.  Finn oppgave");
                Console.WriteLine("7.  Legg til ansatt");
                Console.WriteLine("8.  Legg til stilling");
                Console.WriteLine("9.  Legg til oppgave");
                Console.WriteLine("10. Slett ansatt");
                Console.WriteLine("11. Slett stilling");
                Console.WriteLine("12. Slett oppgave");
                Console.WriteLine("13. Avslutt");
                Console.Write("Velg: ");

                var valg = Console.ReadLine()?.Trim();
                Console.WriteLine();

                try
                {
                    switch (valg)
                    {
                        case "1": ListAnsatte(); break;
                        case "2": ListStillinger(); break;
                        case "3": ListOppgaver(); break;
                        case "4": FinnAnsatt(); break;
                        case "5": FinnStilling(); break;
                        case "6": FinnOppgave(); break;
                        case "7": LeggTilAnsatt(); break;
                        case "8": LeggTilStilling(); break;
                        case "9": LeggTilOppgave(); break;
                        case "10": SlettAnsatt(); break;
                        case "11": SlettStilling(); break;
                        case "12": SlettOppgave(); break;
                        case "13": return;
                        default: Console.WriteLine("Ugyldig valg."); break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"FEIL: {ex.Message}");
                }
            }
        }

        private static void ListAnsatte()
        {
            var liste = _svc.HentAlleAnsatte();
            Console.WriteLine("--- ANSATTE ---");
            foreach (var a in liste) Console.WriteLine($"Fødselsnummer={a.Id}, Navn={a.Navn}");
        }

        private static void ListStillinger()
        {
            var liste = _svc.HentAlleStillinger();
            Console.WriteLine("--- STILLINGER ---");
            foreach (var s in liste) Console.WriteLine($"Id={s.Id}, Fødselsnummer={s.AnsattId}, Navn={s.Navn}, Periode={s.Start:yyyy-MM-dd} til {s.Slutt:yyyy-MM-dd}");
        }

        private static void ListOppgaver()
        {
            var liste = _svc.HentAlleOppgaver();
            Console.WriteLine("--- OPPGAVER ---");
            foreach (var o in liste) Console.WriteLine($"Id={o.Id}, Fødselsnummer={o.AnsattId}, Navn={o.Navn}, Dato={o.Dato:yyyy-MM-dd}");
        }

        private static void FinnAnsatt()
        {
            string id = LesNavn("Skriv fødselsnummer: ");
            var a = _svc.FinnAnsatt(id);
            if (a != null) Console.WriteLine($"Id={a.Id}, Navn={a.Navn}");
            else Console.WriteLine("Fant ikke ansatt.");
        }

        private static void FinnStilling()
        {
            int id = LesInt("Skriv stillings-id: ");
            var s = _svc.FinnStilling(id);
            if (s != null) Console.WriteLine($"Id={s.Id}, Fødselsnummer={s.AnsattId}, Navn={s.Navn}, Periode={s.Start:yyyy-MM-dd} til {s.Slutt:yyyy-MM-dd}");
            else Console.WriteLine("Fant ikke stilling.");
        }

        private static void FinnOppgave()
        {
            int id = LesInt("Skriv oppgave-id: ");
            var o = _svc.FinnOppgave(id);
            if (o != null) Console.WriteLine($"Id={o.Id}, Fødselsnummer={o.AnsattId}, Navn={o.Navn}, Dato={o.Dato:yyyy-MM-dd}");
            else Console.WriteLine("Fant ikke oppgave.");
        }

        private static void LeggTilAnsatt()
        {
            string id = LesNavn("Fødselsnummer: ");
            string navn = LesNavn("Ansattnavn: ");
            try
            {
                var a = _svc.LeggTilAnsatt(id, navn);
                Console.WriteLine($"Lagt til ansatt: Fødselsnummer={a.Id}, Navn={a.Navn}");
            }
            catch (InvalidDataException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void LeggTilStilling()
        {
            string ansattId = LesNavn("Fødselsnummer: ");
            string navn = LesNavn("Stillingstittel: ");
            var start = LesDato($"Start ({DatoFormat}): ");
            var slutt = LesDato($"Slutt ({DatoFormat}): ");
            try
            {
                var s = _svc.LeggTilStilling(ansattId, navn, start, slutt);
                Console.WriteLine($"Lagt til stilling: Id={s.Id}");
            }
            catch (InvalidDataException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void LeggTilOppgave()
        {
            string ansattId = LesNavn("Fødselsnummer: ");
            string navn = LesNavn("Oppgavenavn: ");
            var dato = LesDato($"Dato ({DatoFormat}): ");

            try
            {
                var oppgave = _svc.LeggTilOppgave(ansattId, navn, dato);
                if (oppgave != null)
                {
                    Console.WriteLine($"Lagt til oppgave: Id={oppgave.Id}");
                }
            }
            catch (InvalidDataException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (DuplicateNameException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void SlettAnsatt()
        {
            string id = LesNavn("Skriv fødselsnummer som skal slettes: ");
            bool ok = _svc.SlettAnsatt(id);
            Console.WriteLine(ok ? "Ansatt slettet." : "Fant ikke ansatt.");
        }

        private static void SlettStilling()
        {
            int id = LesInt("Skriv stillings-id som skal slettes: ");
            bool ok = _svc.SlettStilling(id);
            Console.WriteLine(ok ? "Stilling slettet." : "Fant ikke stilling.");
        }

        private static void SlettOppgave()
        {
            int id = LesInt("Skriv oppgave-id som skal slettes: ");
            bool ok = _svc.SlettOppgave(id);
            Console.WriteLine(ok ? "Oppgave slettet." : "Fant ikke oppgave.");
        }

        private static DateOnly LesDato(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                var s = Console.ReadLine();
                if (DateOnly.TryParseExact(s, DatoFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out var d))
                    return d;
                Console.WriteLine($"Ugyldig dato. Bruk format {DatoFormat}.");
            }
        }

        private static int LesInt(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                var s = Console.ReadLine();
                if (int.TryParse(s, out int v)) return v;
                Console.WriteLine("Ugyldig tall. Prøv igjen.");
            }
        }

        private static string LesNavn(string prompt)
        {
            while (true)
            {
                Console.Write(prompt);
                var s = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(s)) return s.Trim();
                Console.WriteLine("Tekst kan ikke være tom. Prøv igjen.");
            }
        }
    }
}

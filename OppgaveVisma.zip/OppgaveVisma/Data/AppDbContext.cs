using Microsoft.EntityFrameworkCore;
using OppgaveVisma.Models;

namespace OppgaveVisma.Data
{
    // EF Core DbContext for SQLite: tabeller, kobling, relasjoner/unikheter
    public class AppDbContext : DbContext
    {
        public DbSet<Ansatt> Ansatte => Set<Ansatt>();
        public DbSet<Stilling> Stillinger => Set<Stilling>();
        public DbSet<Oppgave> Oppgaver => Set<Oppgave>();

        private readonly string _dbPath;

        public AppDbContext()
        {
            var folder = Directory.GetCurrentDirectory();
            _dbPath = Path.Combine(folder, "oppgave.db");
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
            => optionsBuilder.UseSqlite($"Data Source={_dbPath}");

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            // Unikheter
            modelBuilder.Entity<Ansatt>().HasIndex(a => a.Id).IsUnique();
            modelBuilder.Entity<Stilling>().HasIndex(s => new { s.AnsattId, s.Navn, s.Start, s.Slutt }).IsUnique();
            modelBuilder.Entity<Oppgave>().HasIndex(o => new { o.AnsattId, o.Navn, o.Dato }).IsUnique();


            // Relasjoner + kaskade
            modelBuilder.Entity<Ansatt>()
                .Property(a => a.Id)
                .ValueGeneratedNever();
                
            modelBuilder.Entity<Stilling>()
                .HasOne(s => s.Ansatt)
                .WithMany(a => a.Stillinger)
                .HasForeignKey(s => s.AnsattId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Oppgave>()
                .HasOne(o => o.Ansatt)
                .WithMany(a => a.Oppgaver)
                .HasForeignKey(o => o.AnsattId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}

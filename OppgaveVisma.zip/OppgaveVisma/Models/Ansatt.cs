namespace OppgaveVisma.Models
{
    // Domene: ansatt med relasjoner til stillinger og oppgaver
    public class Ansatt
    {
        public string Id { get; set; } = string.Empty;
        public string Navn { get; set; } = string.Empty;

        public List<Stilling> Stillinger { get; set; } = new();
        public List<Oppgave> Oppgaver { get; set; } = new();
    }
}

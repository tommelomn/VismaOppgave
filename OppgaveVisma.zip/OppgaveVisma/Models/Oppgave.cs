namespace OppgaveVisma.Models
{
    // Domene: oppgave knyttet til ansatt + dato
    public class Oppgave
    {
        public int Id { get; set; }
        public string Navn { get; set; } = string.Empty;

        public string AnsattId { get; set; } = string.Empty;
        public Ansatt? Ansatt { get; set; }

        public DateOnly Dato { get; set; }
    }
}

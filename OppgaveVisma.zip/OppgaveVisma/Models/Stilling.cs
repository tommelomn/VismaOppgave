namespace OppgaveVisma.Models
{
    // Domene: stilling (navn, ansatt, periode)
    public class Stilling
    {
        public int Id { get; set; }
        public string Navn { get; set; } = string.Empty;

        public string AnsattId { get; set; } = string.Empty;
        public Ansatt? Ansatt { get; set; }

        public DateOnly Start { get; set; }
        public DateOnly Slutt { get; set; }
    }
}
